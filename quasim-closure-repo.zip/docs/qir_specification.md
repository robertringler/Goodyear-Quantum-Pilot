# QIR Specification

QIR models deterministic operations, constants, safety barriers, and domain attributes.