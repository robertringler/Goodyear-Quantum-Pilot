# HAL Architecture

CPU, GPU, FPGA abstractions with telemetry collection.