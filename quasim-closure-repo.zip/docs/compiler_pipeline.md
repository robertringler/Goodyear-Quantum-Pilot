# Compiler Pipeline

Lexing, parsing, QIR generation, optimization, and lowering to deterministic runtime.