# QSK Kernel Architecture

Describes the sovereign deterministic kernel, scheduler, and syscalls.